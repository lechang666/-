% 清空环境变量
clear;
clc;

% 加载数据 (从附件1和附件2中提取数据)
load_data = readtable('C:\Users\86139\Desktop\24电工杯\附件1：各园区典型日负荷数据.xlsx');
pv_wind_data = readtable('C:\Users\86139\Desktop\24电工杯\附件2：各园区典型日风光发电数据.xlsx');

% 提取各园区的负荷数据和风光发电数据
load_A = load_data.load_A;
load_B = load_data.load_B;
load_C = load_data.load_C;
pv_A = pv_wind_data.pv_A;
pv_C = pv_wind_data.pv_C;
wind_B = pv_wind_data.wind_B;
wind_C = pv_wind_data.wind_C;

% 参数设置
C_grid = 1; % 网购电价 (元/kWh)
C_PV = 0.4; % 光伏发电成本 (元/kWh)
C_Wind = 0.5; % 风力发电成本 (元/kWh)

% 时间步数 (假设为24小时，每小时一个时间步)
T = 24;

% 计算每个园区的购电量
P_grid_A = zeros(T,1);
P_grid_B = zeros(T,1);
P_grid_C = zeros(T,1);

for t = 1:T
    % 园区A购电量
    P_grid_A(t) = max(load_A(t) - pv_A(t), 0);
    
    % 园区B购电量
    P_grid_B(t) = max(load_B(t) - wind_B(t), 0);
    
    % 园区C购电量
    P_grid_C(t) = max(load_C(t) - (pv_C(t) + wind_C(t)), 0);
end

% 计算总购电成本
total_cost_A_grid = sum(P_grid_A) * C_grid;
total_cost_B_grid = sum(P_grid_B) * C_grid;
total_cost_C_grid = sum(P_grid_C) * C_grid;

% 计算光伏发电和风力发电的成本
total_cost_A_PV = sum(pv_A) * C_PV;
total_cost_B_Wind = sum(wind_B) * C_Wind;
total_cost_C_PV = sum(pv_C) * C_PV;
total_cost_C_Wind = sum(wind_C) * C_Wind;

% 计算各园区的总成本
total_cost_A = total_cost_A_grid + total_cost_A_PV;
total_cost_B = total_cost_B_grid + total_cost_B_Wind;
total_cost_C = total_cost_C_grid + total_cost_C_PV + total_cost_C_Wind;

% 计算平均供电成本
average_cost_A = total_cost_A / sum(load_A);
average_cost_B = total_cost_B / sum(load_B);
average_cost_C = total_cost_C / sum(load_C);

% 显示总成本和平均供电成本
disp(['园区A总成本: ', num2str(total_cost_A), ' 元']);
disp(['园区A平均供电成本: ', num2str(average_cost_A), ' 元/kWh']);
disp(['园区B总成本: ', num2str(total_cost_B), ' 元']);
disp(['园区B平均供电成本: ', num2str(average_cost_B), ' 元/kWh']);
disp(['园区C总成本: ', num2str(total_cost_C), ' 元']);
disp(['园区C平均供电成本: ', num2str(average_cost_C), ' 元/kWh']);

% 结果可视化
figure;
subplot(3,1,1);
plot(1:T, load_A, '-o', 1:T, pv_A, '-*', 1:T, P_grid_A, '-x');
title('园区A');
xlabel('时间 (h)');
ylabel('功率 (kW)');
legend('负荷', '光伏发电', '从主电网购电量');

subplot(3,1,2);
plot(1:T, load_B, '-o', 1:T, wind_B, '-*', 1:T, P_grid_B, '-x');
title('园区B');
xlabel('时间 (h)');
ylabel('功率 (kW)');
legend('负荷', '风电发电', '从主电网购电量');

subplot(3,1,3);
plot(1:T, load_C, '-o', 1:T, pv_C, '-*', 1:T, wind_C, '-*', 1:T, P_grid_C, '-x');
title('园区C');
xlabel('时间 (h)');
ylabel('功率 (kW)');
legend('负荷', '光伏发电', '风电发电', '从主电网购电量');
