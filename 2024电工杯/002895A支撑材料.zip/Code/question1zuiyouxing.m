% 清空环境变量
clear;
clc;

% 加载数据 (从附件1和附件2中提取数据)
load_data = readtable('C:\Users\86139\Desktop\24电工杯\附件1：各园区典型日负荷数据.xlsx');
pv_wind_data = readtable('C:\Users\86139\Desktop\24电工杯\附件2：各园区典型日风光发电数据.xlsx');

% 提取各园区的负荷数据和风光发电数据
load_A = load_data.load_A;
load_B = load_data.load_B;
load_C = load_data.load_C;
pv_A = pv_wind_data.pv_A;
pv_C = pv_wind_data.pv_C;
wind_B = pv_wind_data.wind_B;
wind_C = pv_wind_data.wind_C;

% 参数设置
C_grid = 1; % 网购电价 (元/kWh)
C_power = 800; % 储能功率单价 (元/kW)
C_energy = 1800; % 储能容量单价 (元/kWh)
C_PV = 0.4; % 光伏发电成本 (元/kWh)
C_Wind = 0.5; % 风力发电成本 (元/kWh)
eta_charge = 0.95; % 充电效率
eta_discharge = 0.95; % 放电效率
SOC_min = 0.1; % SOC最小值
SOC_max = 0.9; % SOC最大值

% 假设的储能系统配置 (50kW/100kWh)
P_B = 50; % 储能功率 (kW)
E_B = 100; % 储能容量 (kWh)

% 时间步数 (假设为24小时，每小时一个时间步)
T = 24;

% 定义决策变量
P_grid_A = sdpvar(T,1); % 园区A从主电网购电量
P_grid_B = sdpvar(T,1); % 园区B从主电网购电量
P_grid_C = sdpvar(T,1); % 园区C从主电网购电量
P_B_in_A = sdpvar(T,1); % 园区A储能充电功率
P_B_out_A = sdpvar(T,1); % 园区A储能放电功率
P_B_in_B = sdpvar(T,1); % 园区B储能充电功率
P_B_out_B = sdpvar(T,1); % 园区B储能放电功率
P_B_in_C = sdpvar(T,1); % 园区C储能充电功率
P_B_out_C = sdpvar(T,1); % 园区C储能放电功率
SOC_A = sdpvar(T,1); % 园区A储能SOC
SOC_B = sdpvar(T,1); % 园区B储能SOC
SOC_C = sdpvar(T,1); % 园区C储能SOC

% 目标函数：最小化各园区总成本
objective = sum(P_grid_A) * C_grid + sum(P_grid_B) * C_grid + sum(P_grid_C) * C_grid + ...
            P_B * C_power * 3 + E_B * C_energy * 3 + ...
            sum(pv_A) * C_PV + sum(pv_C) * C_PV + sum(wind_B) * C_Wind + sum(wind_C) * C_Wind;

% 约束条件
constraints = [];

% 初始SOC
constraints = [constraints, SOC_A(1) == E_B * 0.5, SOC_B(1) == E_B * 0.5, SOC_C(1) == E_B * 0.5];

for t = 1:T
    % 园区A的约束
    constraints = [constraints, pv_A(t) + P_grid_A(t) + P_B_out_A(t) - P_B_in_A(t) == load_A(t)];
    constraints = [constraints, 0 <= P_B_in_A(t) <= P_B];
    constraints = [constraints, 0 <= P_B_out_A(t) <= P_B];
    constraints = [constraints, SOC_min * E_B <= SOC_A(t) <= SOC_max * E_B];
    if t == 1
        constraints = [constraints, SOC_A(t) == E_B * 0.5 + eta_charge * P_B_in_A(t) - P_B_out_A(t) / eta_discharge];
    else
        constraints = [constraints, SOC_A(t) == SOC_A(t-1) + eta_charge * P_B_in_A(t) - P_B_out_A(t) / eta_discharge];
    end

    % 园区B的约束
    constraints = [constraints, wind_B(t) + P_grid_B(t) + P_B_out_B(t) - P_B_in_B(t) == load_B(t)];
    constraints = [constraints, 0 <= P_B_in_B(t) <= P_B];
    constraints = [constraints, 0 <= P_B_out_B(t) <= P_B];
    constraints = [constraints, SOC_min * E_B <= SOC_B(t) <= SOC_max * E_B];
    if t == 1
        constraints = [constraints, SOC_B(t) == E_B * 0.5 + eta_charge * P_B_in_B(t) - P_B_out_B(t) / eta_discharge];
    else
        constraints = [constraints, SOC_B(t) == SOC_B(t-1) + eta_charge * P_B_in_B(t) - P_B_out_B(t) / eta_discharge];
    end

    % 园区C的约束
    constraints = [constraints, pv_C(t) + wind_C(t) + P_grid_C(t) + P_B_out_C(t) - P_B_in_C(t) == load_C(t)];
    constraints = [constraints, 0 <= P_B_in_C(t) <= P_B];
    constraints = [constraints, 0 <= P_B_out_C(t) <= P_B];
    constraints = [constraints, SOC_min * E_B <= SOC_C(t) <= SOC_max * E_B];
    if t == 1
        constraints = [constraints, SOC_C(t) == E_B * 0.5 + eta_charge * P_B_in_C(t) - P_B_out_C(t) / eta_discharge];
    else
        constraints = [constraints, SOC_C(t) == SOC_C(t-1) + eta_charge * P_B_in_C(t) - P_B_out_C(t) / eta_discharge];
    end
end

% 使用linprog进行优化求解
options = sdpsettings('solver', 'linprog', 'verbose', 1);
sol = optimize(constraints, objective, options);

if sol.problem == 0
    % 提取优化结果
    P_grid_A_opt = value(P_grid_A);
    P_grid_B_opt = value(P_grid_B);
    P_grid_C_opt = value(P_grid_C);
    P_B_in_A_opt = value(P_B_in_A);
    P_B_out_A_opt = value(P_B_out_A);
    P_B_in_B_opt = value(P_B_in_B);
    P_B_out_B_opt = value(P_B_out_B);
    P_B_in_C_opt = value(P_B_in_C);
    P_B_out_C_opt = value(P_B_out_C);
    SOC_A_opt = value(SOC_A);
    SOC_B_opt = value(SOC_B);
    SOC_C_opt = value(SOC_C);
    
    % 计算总成本和平均供电成本
    total_cost_A = sum(P_grid_A_opt) * C_grid + P_B * C_power + E_B * C_energy + sum(pv_A) * C_PV;
    total_cost_B = sum(P_grid_B_opt) * C_grid + P_B * C_power + E_B * C_energy + sum(wind_B) * C_Wind;
    total_cost_C = sum(P_grid_C_opt) * C_grid + P_B * C_power + E_B * C_energy + sum(pv_C) * C_PV + sum(wind_C) * C_Wind;
    average_cost_A = total_cost_A / sum(load_A);
    average_cost_B = total_cost_B / sum(load_B);
    average_cost_C = total_cost_C / sum(load_C);
    
    % 显示各园区总成本和平均供电成本
    disp(['园区A总成本: ', num2str(total_cost_A), ' 元']);
    disp(['园区A平均供电成本: ', num2str(average_cost_A), ' 元/kWh']);
    disp(['园区B总成本: ', num2str(total_cost_B), ' 元']);
    disp(['园区B平均供电成本: ', num2str(average_cost_B), ' 元/kWh']);
    disp(['园区C总成本: ', num2str(total_cost_C), ' 元']);
    disp(['园区C平均供电成本: ', num2str(average_cost_C), ' 元/kWh']);
    
    % 可视化结果
    figure;
    subplot(4,1,1);
    plot(1:T, P_grid_A_opt, '-o');
    title('园区A从主电网购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    
    subplot(4,1,2);
    plot(1:T, P_B_in_A_opt, '-o');
    hold on;
    plot(1:T, P_B_out_A_opt, '-o');
    title('园区A储能充放电功率');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('充电功率', '放电功率');
    
    subplot(4,1,3);
    plot(1:T, SOC_A_opt, '-o');
    title('园区A储能SOC');
    xlabel('时间 (h)');
    ylabel('SOC (kWh)');
    
    subplot(4,1,4);
    plot(1:T, load_A, '-o', 1:T, pv_A, '-*', 1:T, P_grid_A_opt, '-x');
    title('园区A总负荷与发电量及购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('总负荷', '总发电量', '从主电网购电量');
    
    figure;
    subplot(4,1,1);
    plot(1:T, P_grid_B_opt, '-o');
    title('园区B从主电网购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    
    subplot(4,1,2);
    plot(1:T, P_B_in_B_opt, '-o');
    hold on;
    plot(1:T, P_B_out_B_opt, '-o');
    title('园区B储能充放电功率');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('充电功率', '放电功率');
    
    subplot(4,1,3);
    plot(1:T, SOC_B_opt, '-o');
    title('园区B储能SOC');
    xlabel('时间 (h)');
    ylabel('SOC (kWh)');
    
    subplot(4,1,4);
    plot(1:T, load_B, '-o', 1:T, wind_B, '-*', 1:T, P_grid_B_opt, '-x');
    title('园区B总负荷与发电量及购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('总负荷', '总发电量', '从主电网购电量');
    
    figure;
    subplot(4,1,1);
    plot(1:T, P_grid_C_opt, '-o');
    title('园区C从主电网购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    
    subplot(4,1,2);
    plot(1:T, P_B_in_C_opt, '-o');
    hold on;
    plot(1:T, P_B_out_C_opt, '-o');
    title('园区C储能充放电功率');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('充电功率', '放电功率');
    
    subplot(4,1,3);
    plot(1:T, SOC_C_opt, '-o');
    title('园区C储能SOC');
    xlabel('时间 (h)');
    ylabel('SOC (kWh)');
    
    subplot(4,1,4);
    plot(1:T, load_C, '-o', 1:T, pv_C + wind_C, '-*', 1:T, P_grid_C_opt, '-x');
    title('园区C总负荷与发电量及购电量');
    xlabel('时间 (h)');
    ylabel('功率 (kW)');
    legend('总负荷', '总发电量', '从主电网购电量');
else
    disp('优化问题求解失败');
end
% 定义储能配置组合
P_B_values = [10, 20, 30, 40, 50]; % 储能功率 (kW)
E_B_values = [50, 100, 150, 200, 250]; % 储能容量 (kWh)

best_total_cost = inf;
best_P_B = 0;
best_E_B = 0;

for i = 1:length(P_B_values)
    for j = 1:length(E_B_values)
        P_B = P_B_values(i);
        E_B = E_B_values(j);

        % 重新定义决策变量和约束条件
        P_grid_A = sdpvar(T,1); % 园区A从主电网购电量
        P_grid_B = sdpvar(T,1); % 园区B从主电网购电量
        P_grid_C = sdpvar(T,1); % 园区C从主电网购电量
        P_B_in_A = sdpvar(T,1); % 园区A储能充电功率
        P_B_out_A = sdpvar(T,1); % 园区A储能放电功率
        P_B_in_B = sdpvar(T,1); % 园区B储能充电功率
        P_B_out_B = sdpvar(T,1); % 园区B储能放电功率
        P_B_in_C = sdpvar(T,1); % 园区C储能充电功率
        P_B_out_C = sdpvar(T,1); % 园区C储能放电功率
        SOC_A = sdpvar(T,1); % 园区A储能SOC
        SOC_B = sdpvar(T,1); % 园区B储能SOC
        SOC_C = sdpvar(T,1); % 园区C储能SOC

        % 目标函数：最小化各园区总成本
        objective = sum(P_grid_A) * C_grid + sum(P_grid_B) * C_grid + sum(P_grid_C) * C_grid + ...
                    P_B * C_power * 3 + E_B * C_energy * 3 + ...
                    sum(pv_A) * C_PV + sum(pv_C) * C_PV + sum(wind_B) * C_Wind + sum(wind_C) * C_Wind;

        % 约束条件
        constraints = [];

        % 初始SOC
        constraints = [constraints, SOC_A(1) == E_B * 0.5, SOC_B(1) == E_B * 0.5, SOC_C(1) == E_B * 0.5];

        for t = 1:T
            % 园区A的约束
            constraints = [constraints, pv_A(t) + P_grid_A(t) + P_B_out_A(t) - P_B_in_A(t) == load_A(t)];
            constraints = [constraints, 0 <= P_B_in_A(t) <= P_B];
            constraints = [constraints, 0 <= P_B_out_A(t) <= P_B];
            constraints = [constraints, SOC_min * E_B <= SOC_A(t) <= SOC_max * E_B];
            if t == 1
                constraints = [constraints, SOC_A(t) == E_B * 0.5 + eta_charge * P_B_in_A(t) - P_B_out_A(t) / eta_discharge];
            else
                constraints = [constraints, SOC_A(t) == SOC_A(t-1) + eta_charge * P_B_in_A(t) - P_B_out_A(t) / eta_discharge];
            end

            % 园区B的约束
            constraints = [constraints, wind_B(t) + P_grid_B(t) + P_B_out_B(t) - P_B_in_B(t) == load_B(t)];
            constraints = [constraints, 0 <= P_B_in_B(t) <= P_B];
            constraints = [constraints, 0 <= P_B_out_B(t) <= P_B];
            constraints = [constraints, SOC_min * E_B <= SOC_B(t) <= SOC_max * E_B];
            if t == 1
                constraints = [constraints, SOC_B(t) == E_B * 0.5 + eta_charge * P_B_in_B(t) - P_B_out_B(t) / eta_discharge];
            else
                constraints = [constraints, SOC_B(t) == SOC_B(t-1) + eta_charge * P_B_in_B(t) - P_B_out_B(t) / eta_discharge];
            end

            % 园区C的约束
            constraints = [constraints, pv_C(t) + wind_C(t) + P_grid_C(t) + P_B_out_C(t) - P_B_in_C(t) == load_C(t)];
            constraints = [constraints, 0 <= P_B_in_C(t) <= P_B];
            constraints = [constraints, 0 <= P_B_out_C(t) <= P_B];
            constraints = [constraints, SOC_min * E_B <= SOC_C(t) <= SOC_max * E_B];
            if t == 1
                constraints = [constraints, SOC_C(t) == E_B * 0.5 + eta_charge * P_B_in_C(t) - P_B_out_C(t) / eta_discharge];
            else
                constraints = [constraints, SOC_C(t) == SOC_C(t-1) + eta_charge * P_B_in_C(t) - P_B_out_C(t) / eta_discharge];
            end
        end

        % 使用linprog进行优化求解
        options = sdpsettings('solver', 'linprog', 'verbose', 0);
        sol = optimize(constraints, objective, options);

        if sol.problem == 0
            % 提取优化结果
            total_cost = value(objective);
            if total_cost < best_total_cost
                best_total_cost = total_cost;
                best_P_B = P_B;
                best_E_B = E_B;
            end
        end
    end
end

% 显示最优储能配置方案
disp(['最优储能功率: ', num2str(best_P_B), ' kW']);
disp(['最优储能容量: ', num2str(best_E_B), ' kWh']);
disp(['最优方案总成本: ', num2str(best_total_cost), ' 元']);
