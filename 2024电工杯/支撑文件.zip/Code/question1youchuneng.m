% 清空环境变量
clear;
clc;

% 读取负荷数据
load_data = readmatrix('C:\Users\86139\Desktop\24电工杯\附件1：各园区典型日负荷数据.xlsx'); 
% 读取风光发电数据
wind_solar_data = readmatrix('C:\Users\86139\Desktop\24电工杯\附件2：各园区典型日风光发电数据.xlsx'); 

% 参数设置
SOC_max = 0.9;
SOC_min = 0.1;
charge_efficiency = 0.95;
discharge_efficiency = 0.95;
electricity_price = 1; % 电网电价（元/千瓦时）
wind_cost_per_kwh = 0.5; % 风力发电成本（元/千瓦时）
solar_cost_per_kwh = 0.4; % 光伏发电成本（元/千瓦时）

% 初始化变量
num_hours = size(load_data, 2);
battery_capacity = 200; % kWh
battery_power = 100; % kW
battery_SOC = zeros(num_hours,2);
battery_SOC(1) = battery_capacity * SOC_min;

% 计算购电量和弃风弃光量
grid_purchase = zeros(num_hours, 1);
wind_solar_waste = zeros(num_hours, 1);

% 计算储能策略
for t = 2:num_hours
    % 计算可充电量和可放电量
    charge_amount = min(battery_capacity * SOC_max - battery_SOC(t-1), max(0, (wind_solar_data(t,2) - load_data(t,2)) * charge_efficiency));
    discharge_amount = min(battery_SOC(t-1) - battery_capacity * SOC_min, max(0, (load_data(t,2) - wind_solar_data(t,2)) / discharge_efficiency));
    
    % 更新电池SOC
    battery_SOC(t) = battery_SOC(t-1) + charge_amount - discharge_amount;
    
    % 更新购电量和弃风弃光量
    grid_purchase(t) = max(0, load_data(t,2) - wind_solar_data(t,2) - discharge_amount);
    wind_solar_waste(t) = max(0, wind_solar_data(t,2) - load_data(t,2) - charge_amount);
end

% 计算风光发电成本
wind_generated = wind_solar_data(:,3); % 风力发电量
solar_generated = wind_solar_data(:,4); % 光伏发电量

wind_cost = sum(wind_generated) * wind_cost_per_kwh;
solar_cost = sum(solar_generated) * solar_cost_per_kwh;

% 计算电网购电成本
grid_cost = sum(grid_purchase) * electricity_price;

% 总供电成本
total_cost = wind_cost + solar_cost + grid_cost;

% 计算单位电量平均供电成本
total_load = sum(load_data(:,2));
avg_cost_per_kwh = total_cost / total_load;

% 输出结果
fprintf('--- With Storage (Including Wind and Solar Costs) ---\n');
fprintf('Total Grid Purchase: %.2f kWh\n', sum(grid_purchase));
fprintf('Total Wind and Solar Waste: %.2f kWh\n', sum(wind_solar_waste));
fprintf('Wind Power Cost: %.2f Yuan\n', wind_cost);
fprintf('Solar Power Cost: %.2f Yuan\n', solar_cost);
fprintf('Total Grid Cost: %.2f Yuan\n', grid_cost);
fprintf('Total Cost: %.2f Yuan\n', total_cost);
fprintf('Average Cost per kWh: %.2f Yuan/kWh\n', avg_cost_per_kwh);

% 可视化结果
time = (1:num_hours)'; % 时间序列

figure;
subplot(3,1,1);
plot(time, grid_purchase, '-b', 'LineWidth', 1.5);
title('Grid Purchase Over Time (With Storage)');
xlabel('Time (hours)');
ylabel('Grid Purchase (kWh)');
grid on;

subplot(3,1,2);
plot(time, wind_solar_waste, '-r', 'LineWidth', 1.5);
title('Wind and Solar Waste Over Time (With Storage)');
xlabel('Time (hours)');
ylabel('Waste (kWh)');
grid on;

subplot(3,1,3);
plot(time, battery_SOC, '-g', 'LineWidth', 1.5);
title('Battery State of Charge (SOC) Over Time');
xlabel('Time (hours)');
ylabel('SOC (kWh)');
grid on;

% 保存图表
saveas(gcf, 'results_with_storage.png');
