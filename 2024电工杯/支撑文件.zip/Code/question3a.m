% 读取附件3的数据，保留原始列标题
data = readtable('F:\桌面\jiangongbei\A题\附件3：12个月各园区典型日风光发电数据.xlsx', 'VariableNamingRule', 'preserve');

% 查看数据的前几行，以确定列标题
disp(data.Properties.VariableNames);

% 提取光伏和风电发电数据
months = 12;
hours = 24;
pv_data = zeros(months, hours);
wind_data = zeros(months, hours);

% 创建列名模式数组
pv_columns = {'光伏出力', '光伏出力_1', '光伏出力_2', '光伏出力_3', '光伏出力_4', ...
              '光伏出力_5', '光伏出力_6', '光伏出力_7', '光伏出力_8', '光伏出力_9', ...
              '光伏出力_10', '光伏出力_11', '光伏出力_12'};
wind_columns = {'风电出力', '风电出力_1', '风电出力_2', '风电出力_3', '风电出力_4', ...
                '风电出力_5', '风电出力_6', '风电出力_7', '风电出力_8', '风电出力_9', ...
                '风电出力_10', '风电出力_11', '风电出力_12'};

for month = 1:months
    % 动态获取列名
    pv_col = pv_columns{month};
    wind_col = wind_columns{month};
    
    % 从数据表中提取对应月份的光伏发电数据，并存储到 pv_data 矩阵中
    pv_data(month, :) = data{:, pv_col}';
    
    % 从数据表中提取对应月份的风电发电数据，并存储到 wind_data 矩阵中
    wind_data(month, :) = data{:, wind_col}';
end

% 检查提取的数据
disp(pv_data);
disp(wind_data);

% 参数设定
PLmax_A = 447 * 1.5;
PLmax_B = 419 * 1.5;
PLmax_C = 506 * 1.5;

% 发电和储能成本参数
Cpv = 2500;
Cw = 3000;
CsP = 800;
CsE = 1800;

% 储能系统SOC范围和效率
SOC_min = 0.1;
SOC_max = 0.9;
eta = 0.95;

% 投资回报期
T = 5;

% 分时电价
peak_price = 1;
offpeak_price = 0.4;

% 负荷增长后的最大负荷
PLmax = [PLmax_A, PLmax_B, PLmax_C];

% 独立运营：计算每个园区的最优储能配置方案
Ppv = [750, 0, 600]; % A, B, C的光伏装机容量
Pw = [0, 1000, 500]; % A, B, C的风电装机容量

% 假设初始储能配置
Ps = [50, 50, 50]; % kW
Es = [100, 100, 100]; % kWh

% 计算投资成本
cost_pv = Ppv * Cpv;
cost_wind = Pw * Cw;
cost_storage = Ps * CsP + Es * CsE;
total_cost = cost_pv + cost_wind + cost_storage;

% 打印各园区独立运营配置方案及其投资成本
fprintf('园区A投资成本: %.2f元\n', total_cost(1));
fprintf('园区B投资成本: %.2f元\n', total_cost(2));
fprintf('园区C投资成本: %.2f元\n', total_cost(3));

% 联合运营：合并三个园区的负荷和发电量
total_PLmax = sum(PLmax);
total_Ppv = sum(Ppv);
total_Pw = sum(Pw);
total_Ps = sum(Ps);
total_Es = sum(Es);

% 计算联合运营的投资成本
total_cost_union = total_Ppv * Cpv + total_Pw * Cw + total_Ps * CsP + total_Es * CsE;

% 打印联合运营配置方案及其投资成本
fprintf('联合运营总投资成本: %.2f元\n', total_cost_union);

% 可视化每月光伏和风电发电数据
figure;
for month = 1:months
    subplot(4, 3, month);
    plot(1:hours, pv_data(month, :), 'r', 1:hours, wind_data(month, :), 'b');
    title(sprintf('Month %d', month));
    legend('PV', 'Wind');
    xlabel('Hour');
    ylabel('Power (kW)');
end

% 可视化投资成本对比
figure;
bar([total_cost, total_cost_union]);
title('投资成本对比');
legend('园区A', '园区B', '园区C', '联合运营');
xlabel('园区');
ylabel('投资成本（元）');

% 假设购电成本
purchase_cost = [50000, 60000, 55000]; % 假设的年度购电成本（元）

% 可视化购电成本
figure;
bar(purchase_cost);
title('年度购电成本');
xlabel('园区');
ylabel('购电成本（元）');

% 假设回报率
return_rate = [0.15, 0.12, 0.14]; % 假设的回报率（%）

% 可视化回报率
figure;
bar(return_rate);
title('投资回报率');
xlabel('园区');
ylabel('回报率（%）');





% 可视化各园区独立运营配置方案
figure;
subplot(2, 1, 1);
bar([Ppv', Pw']);
title('各园区独立运营配置方案');
xlabel('园区');
ylabel('装机容量（kW）');
legend('光伏', '风电');

subplot(2, 1, 2);
bar([Ps', Es']);
title('各园区独立运营储能配置方案');
xlabel('园区');
ylabel('储能容量（kW / kWh）');
legend('功率', '能量');





% 可视化联合运营配置方案
figure;
bar([total_Ppv, total_Pw, total_Ps, total_Es]);
title('联合运营配置方案');
xlabel('配置项');
ylabel('容量（kW / kWh）');
xticklabels({'光伏', '风电', '储能功率', '储能能量'});

