% 读取负荷和发电数据
load_data = xlsread('load_data.xlsx'); % 负荷数据
gen_data = xlsread('联合园区供电.xlsx'); % 风光发电数据

% 数据时间间隔（小时）
time_interval = 1;
time = 0:time_interval:(size(load_data, 1) - 1) * time_interval;

% 光伏和风电的发电成本（元/kWh）
cost_pv = 0.4;
cost_wind = 0.5;

% 主电网购电成本（元/kWh）
cost_grid = 1;

% 初始化变量
total_load = sum(load_data);
total_gen_pv = sum(gen_data(:,1));
total_gen_wind = sum(gen_data(:,2));
total_gen = total_gen_pv + total_gen_wind;
excess_gen = max(0, total_gen - total_load); % 弃风弃光电量
grid_purchase = max(0, total_load - total_gen); % 从主电网购电量

% 计算总供电成本
total_cost_pv = total_gen_pv * cost_pv;
total_cost_wind = total_gen_wind * cost_wind;
total_cost_grid = grid_purchase * cost_grid;
total_cost = total_cost_pv + total_cost_wind + total_cost_grid;

% 计算单位电量平均供电成本
average_cost = total_cost / total_load;

% 显示结果
fprintf('总购电量: %.2f kWh\n', grid_purchase);
fprintf('总弃风弃光电量: %.2f kWh\n', excess_gen);
fprintf('总供电成本: %.2f 元\n', total_cost);
fprintf('单位电量平均供电成本: %.2f 元/kWh\n', average_cost);

% 可视化
figure;

% 负荷与发电量对比
subplot(3, 1, 1);
plot(time, load_data, 'b-', 'LineWidth', 1.5); hold on;
plot(time, gen_data(:,1), 'r--', 'LineWidth', 1.5);
plot(time, gen_data(:,2), 'g--', 'LineWidth', 1.5);
xlabel('时间 (小时)');
ylabel('功率 (kW)');
title('负荷与发电量对比');
legend('负荷', '光伏发电', '风电发电');
grid on;

% 购电量和弃电量
subplot(3, 1, 2);
bar([grid_purchase, excess_gen], 0.4);
set(gca, 'XTickLabel', {'购电量', '弃风弃光电量'});
ylabel('电量 (kWh)');
title('购电量和弃电量');
grid on;

% 总供电成本
subplot(3, 1, 3);
bar([total_cost_pv, total_cost_wind, total_cost_grid, total_cost], 0.4);
set(gca, 'XTickLabel', {'光伏成本', '风电成本', '购电成本', '总成本'});
ylabel('成本 (元)');
title('总供电成本');
grid on;
