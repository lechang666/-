% 读取Excel文件中的数据
load_data = readmatrix('load_data.xlsx');
wind_solar_data = readmatrix('wind_solar_data.xlsx');

% 提取各园区的负荷数据
load_A = load_data(:, 1);
load_B = load_data(:, 2);
load_C = load_data(:, 3);

% 提取光伏和风电数据
P_pv_A = wind_solar_data(:, 1);
P_pv_C = wind_solar_data(:, 2);
P_w_B = wind_solar_data(:, 3);
P_w_C = wind_solar_data(:, 4);

% 设定电网购电成本
C_wind = 0.5; % 风电购电成本 元/kWh
C_pv = 0.4;   % 光伏购电成本 元/kWh
C_grid = 1; % 元/kWh

% 计算每小时的购电量和弃风弃光电量
E_grid = zeros(24, 1);
E_excess = zeros(24, 1);

for t = 1:24
    % 各园区总负荷
    L_total = load_A(t) + load_B(t) + load_C(t);
    
    % 各园区总发电量
    P_pv_total = P_pv_A(t) + P_pv_C(t);
    P_w_total = P_w_B(t) + P_w_C(t);
    
    % 计算净负荷
    L_net = L_total - (P_pv_total + P_w_total);
    
    if L_net > 0
        % 需要从电网购电
        E_grid(t) = L_net;
    else
        % 弃风弃光
        E_excess(t) = -L_net;
    end
end

% 计算总购电量和总弃风弃光电量
total_E_grid = sum(E_grid);
total_E_excess = sum(E_excess);

% 计算总供电成本
total_cost = total_E_grid * C_grid;

% 计算单位电量平均供电成本
total_load = sum(load_A) + sum(load_B) + sum(load_C);
avg_cost = total_cost / total_load;

% 设定储能参数
P_bat_max = 10; % kW
E_bat_capacity = 50; % kWh
SOC_min = 0.1;
SOC_max = 0.9;
eta = 0.95; % 充放电效率

% 初始化储能状态
E_bat = E_bat_capacity * 0.5; % 初始状态设为50% SOC

% 计算配置储能后的购电量
E_grid_storage = zeros(24, 1);

for t = 1:24
    % 各园区总负荷
    L_total = load_A(t) + load_B(t) + load_C(t);
    
    % 各园区总发电量
    P_pv_total = P_pv_A(t) + P_pv_C(t);
    P_w_total = P_w_B(t) + P_w_C(t);
    
    % 计算净负荷
    L_net = L_total - (P_pv_total + P_w_total);
    
    if L_net > 0
        % 负荷大于发电，放电
        P_discharge = min([P_bat_max, L_net / eta, (E_bat - E_bat_capacity * SOC_min)]);
        E_bat = E_bat - P_discharge / eta;
        E_grid_storage(t) = L_net - P_discharge;
    else
        % 发电大于负荷，充电
        P_charge = min([-L_net * eta, P_bat_max, (E_bat_capacity * SOC_max - E_bat)]);
        E_bat = E_bat + P_charge * eta;
        E_grid_storage(t) = 0;
    end
end

% 计算总购电量
total_E_grid_storage = sum(E_grid_storage);

% 计算总供电成本
total_cost_storage = total_E_grid_storage * C_grid;

% 计算单位电量平均供电成本
avg_cost_storage = total_cost_storage / total_load;

% 可视化结果
figure;

% 未配置储能情况下的购电量
subplot(3, 1, 1);
plot(1:24, E_grid, '-o', 'DisplayName', '未配置储能');
hold on;
plot(1:24, E_grid_storage, '-x', 'DisplayName', '配置储能');
title('每小时购电量比较');
xlabel('时间（小时）');
ylabel('购电量（kWh）');
legend('show');

% 弃风弃光量
subplot(3, 1, 2);
plot(1:24, E_excess, '-o', 'DisplayName', '未配置储能');
hold on;
title('每小时弃风弃光量');
xlabel('时间（小时）');
ylabel('弃风弃光量（kWh）');
legend('show');

% 总供电成本和单位电量平均供电成本
subplot(3, 1, 3);
bar([total_cost, total_cost_storage; avg_cost, avg_cost_storage]);
set(gca, 'xticklabel', {'总供电成本', '单位电量平均供电成本'});
legend({'未配置储能', '配置储能'});
title('总供电成本和单位电量平均供电成本比较');
ylabel('成本（元）');

% 显示结果
fprintf('未配置储能时:\n');
fprintf('总购电量: %.2f kWh\n', total_E_grid);
fprintf('总弃风弃光电量: %.2f kWh\n', total_E_excess);
fprintf('总供电成本: %.2f 元\n', total_cost);
fprintf('单位电量平均供电成本: %.2f 元/kWh\n', avg_cost);

fprintf('配置储能后:\n');
fprintf('总购电量: %.2f kWh\n', total_E_grid_storage);
fprintf('总供电成本: %.2f 元\n', total_cost_storage);
fprintf('单位电量平均供电成本: %.2f 元/kWh\n', avg_cost_storage);
