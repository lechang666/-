% 读取Excel文件
data = xlsread('F:\桌面\5.11\diseiwen2y.xlsx', 'Sheet1', 'A1:ALM1');

% 计算相关系数
correlation_coefficient = corr(data');

% 拟合一次函数
x = 1:size(data, 2); % x轴数据
y = data; % y轴数据
coefficients = polyfit(x, y, 1); % 一次多项式拟合

% 计算拟合曲线
fit_line = polyval(coefficients, x);

% 绘制原始数据和拟合曲线
figure;
plot(x, y, 'b.', x, fit_line, 'r-');
xlabel('Time');
ylabel('Data');
title('Data and Fitted Curve');

% 打印相关系数和拟合参数
disp(['相关系数 r = ', num2str(correlation_coefficient)]);
disp(['一次函数系数: ', num2str(coefficients)]);
