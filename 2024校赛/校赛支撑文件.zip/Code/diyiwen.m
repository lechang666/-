% 模拟参数
V_submarine = 30; % 潜水艇体积（立方米）
rho_water = 1025; % 海水密度（千克/立方米）
g = 9.81; % 重力加速度（米/秒^2）
A_submarine = pi * 1 * 1.5; % 潜水艇横截面积（假设为椭圆形，单位：平方米）
Cd = 0.5; % 潜水艇的阻力系数
A = 0.8; % 洋流对潜水艇的横截面积影响系数
v_current = 0.1; % 洋流速度（假设为一个常数，单位：米/秒）

% 导入海底地形图数据
terrain_data =['F:\桌面\Date\aiaoniyahaididixingz.xlsx'];

% 深度比例尺
depth_scale = 100; % 深度比例尺（假设为100，单位：米）

% 时间参数
t_total = 100; % 总时间（秒）
dt = 0.1; % 时间步长（秒）
t = 0:dt:t_total; % 时间数组

% 初始条件
z0 = 0; % 初始深度（假设在海平面上）
v0 = 0; % 初始速度

% 初始化数组
z = zeros(size(t));
v = zeros(size(t));
x = 1200; % 保存潜水艇在x方向的位置
y = 1000; % 保存潜水艇在y方向的位置

% 模拟运动
z(1) = z0;
v(1) = v0;
for i = 2:length(t)
    % 计算上升力
    F_buoyancy = rho_water * V_submarine * g;
    
    % 计算阻力
    F_drag = 0.5 * Cd * rho_water * A_submarine * v(i-1)^2;
    
    % 计算洋流对潜水艇的影响（模拟洋流沿海底的水平速度）
    if i <= size(terrain_data, 1) && z(i-1) > 0
        v_x_current = v_current * interp1(1:size(terrain_data, 2), terrain_data(i, :), z(i-1) / depth_scale, 'linear', 'extrap');
    else
        v_x_current = v_current; % 当潜水艇到达海平面时，只受洋流作用
    end
    if i <= size(terrain_data, 1) && z(i-1) > 0
        v_y_current = v_current * interp1(1:size(terrain_data, 2), terrain_data(i, :), z(i-1) / depth_scale, 'linear', 'extrap');
    else
        v_y_current = v_current; % 当潜水艇到达海平面时，只受洋流作用
    end 
    % 获取当前深度处的海底高度
    if i <= size(terrain_data, 1)
        terrain_height = interp1(1:size(terrain_data, 2), terrain_data(i, :), z(i-1) / depth_scale, 'linear', 'extrap') * depth_scale;
    else
        terrain_height = 0; % 超出海底地形数据的范围时，假设海底高度为0
    end
    
    % 计算海底地形对阻力的影响
    if z(i-1) < terrain_height
        F_terrain = Cd * rho_water * A_submarine * g * (terrain_height - z(i-1));
    else
        F_terrain = 0;
    end
    
    % 计算合力
    F_total = F_buoyancy - F_drag;
    
    % 计算加速度
    a = F_total / (rho_water * V_submarine);
    
    % 计算速度和深度
    v(i) = v(i-1) + a * dt;
    z(i) = max(0, z(i-1) + v(i) * dt); % 深度不允许小于0
    
    % 更新潜水艇在x方向的位置
    x(i) = x(i-1) + v_x_current * dt;
    
    % 更新潜水艇在y方向的位置（假设潜水艇只做直线运动，不考虑侧向位移）
    y(i) = y(i-1) + v_y_current * dt;
    
    % 当潜水艇到达海平面时，停止模拟
    if z(i) == 0 && z(i-1) > 0
        break;
    end
end

% 绘制结果
plot3(x, y, z, 'b-');
xlabel