% 测试动态规划解决三维旅行商问题的函数，并绘制图形

% 读取测试数据
points = rand(10, 3); % 随机生成10个三维点

% 调用函数计算最短路径距离
min_distance = dynamic_programming_3d_tsp(points);

% 显示结果
disp(['最短路径距离: ', num2str(min_distance)]);

% 绘制图形
figure;
plot3(points(:,1), points(:,2), points(:,3), 'bo', 'MarkerSize', 10); % 绘制点
hold on;

% 绘制最短路径
path_order = greedy_tsp(points); % 假设这里使用了贪婪算法找到了近似最短路径
path_points = points(path_order, :);
plot3(path_points(:,1), path_points(:,2), path_points(:,3), 'r-', 'LineWidth', 2); % 绘制路径

xlabel('X');
ylabel('Y');
zlabel('Z');
title('3D TSP Solution');
legend('Points', 'Shortest Path');
hold off;
