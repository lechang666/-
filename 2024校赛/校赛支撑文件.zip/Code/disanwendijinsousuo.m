% 定义搜索区域的大小和初始位置
grid_size = [1001, 1001, 1001]; % 三维网格大小 [x, y, z]
initial_position = [1, 1, 1]; % 初始位置

% 定义目标位置
target_position = [8, 8, 3]; % 目标位置

% 初始化存储搜索位置的矩阵
search_positions = zeros(0, 3); % 初始为空

% 递进式搜索
search_range = 1; % 初始化搜索范围
found_target = false; % 标记是否找到目标
while search_range <= max(grid_size)
    % 在搜索范围内搜索
    for x = max(1, initial_position(1)-search_range):min(grid_size(1), initial_position(1)+search_range)
        for y = max(1, initial_position(2)-search_range):min(grid_size(2), initial_position(2)+search_range)
            for z = max(1, initial_position(3)-search_range):min(grid_size(3), initial_position(3)+search_range)
                % 在当前位置执行搜索操作，这里可以根据具体情况进行操作
           
                disp(['Searching at position (', num2str(x), ', ', num2str(y), ', ', num2str(z), ')']);
                
                % 记录搜索到的位置
                search_positions = [search_positions; x, y, z];
                
                % 检查是否找到目标
                if isequal([x, y, z], target_position)
                    found_target = true;
                    break;
                end
            end
            if found_target
                break;
            end
        end
        if found_target
            break;
        end
    end
    
    % 如果找到目标，则终止搜索
    if found_target
        break;
    end
    
    % 扩大搜索范围
    search_range = search_range + 1;
end

% 绘制位置图
scatter3(search_positions(:, 1), search_positions(:, 2), search_positions(:, 3), 'filled');
hold on;
scatter3(target_position(1), target_position(2), target_position(3), 100, 'r', 'filled'); % 标记目标位置
hold off;
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Progressive Search Positions');
axis equal;
plot3(search_positions(:, 1), search_positions(:, 2), search_positions(:, 3))
% 显示是否找到目标
if found_target
    disp('目标已找到！');
else
    disp('未找到目标。');
end
