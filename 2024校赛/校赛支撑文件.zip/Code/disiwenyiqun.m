% 设置参数
num_robots = 5;  % 水下机器人数量
search_radius = 50;  % 搜索半径
num_iterations = 1000;  % 迭代次数
evaporation_rate = 0.1;  % 信息素蒸发率
pheromone_init = 1;  % 初始信息素浓度
pheromone_max = 10;  % 信息素最大值

% 初始化机器人位置和轨迹
robots_x = rand(1, num_robots) * 2000;  % 海域宽度为100米
robots_y = rand(1, num_robots) * 2000;  % 海域长度为100米
robot_trajectories = zeros(num_robots, 2, num_iterations);

% 初始化信息素矩阵
pheromones = ones(2000, 2000) * pheromone_init;

% 坏掉的水下机器人位置
broken_robot_x = rand() * 2000;
broken_robot_y = rand() * 2000;

% 迭代搜索
for iter = 1:num_iterations
    % 水下机器人搜索
    for i = 1:num_robots
        % 计算当前机器人到其他机器人的距离
        distances = sqrt((robots_x - robots_x(i)).^2 + (robots_y - robots_y(i)).^2);
        
        % 找出搜索范围内的其他机器人
        neighbors = find(distances <= search_radius & (1:num_robots) ~= i);
        
        % 如果当前机器人在搜索半径内找到了坏掉的机器人，则朝着坏掉机器人移动
        if any(neighbors)
            next_x = broken_robot_x;
            next_y = broken_robot_y;
        else
            % 计算信息素浓度
            pheromone_values = pheromones(round(robots_x(i)), round(robots_y(i)));
            
            % 选择下一个搜索位置
            [~, next_index] = max(pheromone_values);
            next_x = robots_x(i) + rand() * 10 - 5;  % 在搜索范围内随机移动
            next_y = robots_y(i) + rand() * 10 - 5;  % 在搜索范围内随机移动
        end
        
        % 更新机器人位置和轨迹
        robots_x(i) = next_x;
        robots_y(i) = next_y;
        robot_trajectories(i, :, iter) = [robots_x(i), robots_y(i)];
        
        % 更新信息素浓度
        pheromones(round(robots_x(i)), round(robots_y(i))) = min(pheromone_max, pheromones(round(robots_x(i)), round(robots_y(i))) + 1);
    end
    
    % 信息素蒸发
    pheromones = pheromones * (1 - evaporation_rate);
end

% 绘制机器人的运动轨迹
figure;
for i = 1:num_robots
    plot(squeeze(robot_trajectories(i, 1, :)), squeeze(robot_trajectories(i, 2, :)));
    hold on;
end

% 绘制坏掉的机器人位置
scatter(broken_robot_x, broken_robot_y, 'r', 'filled');

xlabel('X');
ylabel('Y');
title('Robot Trajectories');
axis([0 2000 0 2000]);
legend('Robot 1', 'Robot 2', 'Robot 3', 'Robot 4', 'Robot 5', 'Broken Robot');
hold off;

