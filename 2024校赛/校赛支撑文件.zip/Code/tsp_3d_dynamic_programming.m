function [min_dist, min_path] = tsp_3d_dynamic_programming(points)
    n = size(points, 2);
    all_sets = 1:2^n;
    dp = inf(n, 2^n);
    dp(1, 1) = 0;
    
    for mask = 1:2^n
        for current_node = 1:n
            if bitget(mask, current_node) == 0
                continue;
            end
            prev_mask = mask - 2^(current_node-1);
            if prev_mask == 0
                continue;
            end
            for prev_node = 1:n
                if bitget(prev_mask, prev_node) == 0
                    continue;
                end
                new_dist = dp(prev_node, prev_mask) + norm(points(prev_node, :) - points(current_node, :));
                dp(current_node, mask) = min(dp(current_node, mask), new_dist);
            end
        end
    end
    
    min_dist = inf;
    for i = 2:n
        min_dist = min(min_dist, dp(i, 2^n-1) + norm(points(i, :) - points(1, :)));
    end
    
    % Reconstruct the path
    current_node = 1;
    current_mask = 2^n - 1;
    min_path = [1];
    for i = 1:n-1
        next_node = -1;
        for j = 1:n
            if bitget(current_mask, j) == 1 && (next_node == -1 || dp(j, current_mask) + norm(points(j, :) - points(current_node, :)) < dp(next_node, current_mask) + norm(points(next_node, :) - points(current_node, :)))
                next_node = j;
            end
        end
        min_path = [min_path, next_node];
        current_mask = current_mask - 2^(next_node-1);
        current_node = next_node;
    end
    min_path = [min_path, 1]; % Return to the start node
end
